class Constants {
  // static String backendUri = "http://localhost:8000";
  static String backendUri = "http://10.0.2.2:8000";
}
