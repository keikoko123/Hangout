package com.example.hangout_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
